import AVFoundation
import Starscream
import os

// MARK: - Deepgram response model

struct DeepgramResponse: Codable {
    // We don't rely on Deepgram's isFinal; we treat each sentence as final.
    let channel: Channel?

    struct Channel: Codable {
        let alternatives: [Alternative]?
    }

    struct Alternative: Codable {
        let transcript: String?
        let words: [Word]?
    }

    struct Word: Codable {
        let word: String
        let speaker: Int?
        let start: Double?
        let end: Double?
    }
}

// MARK: - SpeechProcessor (macOS CLI version)

class SpeechProcessor: WebSocketDelegate {

    // Keeps a running record of all transcripts per speaker
    public private(set) var conversation: [String: [String]] = [:]

    // Logger
    private let logger = Logger(subsystem: "NLP", category: "SpeechProcessor")

    // Audio engine graph
    private let audioEngine = AVAudioEngine()
    private let converterNode = AVAudioMixerNode()
    private let sinkNode = AVAudioMixerNode()

    // Audio format properties
    private let sampleRate: Double
    private let channels: AVAudioChannelCount
    private let interleaved: Bool

    /// We force the converterNode output to Int16 so it matches Deepgram's `linear16` expectation.
    private lazy var outputFormat: AVAudioFormat = {
        AVAudioFormat(
            commonFormat: .pcmFormatInt16,
            sampleRate: sampleRate,
            channels: channels,
            interleaved: interleaved
        )!
    }()

    // Deepgram WebSocket
    private let deepgramKey: String
    private lazy var socket: Starscream.WebSocket = {
        let urlString =
            "wss://api.deepgram.com/v1/listen" +
            "?model=nova-2" +
            "&diarize=true" +
            "&punctuate=true" +
            "&filler_words=true" +          // keep "um", "uh", etc.
            "&encoding=linear16" +
            "&sample_rate=\(Int(sampleRate))" +
            "&channels=\(channels)"

        guard let url = URL(string: urlString) else {
            fatalError("Invalid WebSocket URL")
        }

        var request = URLRequest(url: url)
        request.setValue("Token \(deepgramKey)", forHTTPHeaderField: "Authorization")
        return Starscream.WebSocket(request: request)
    }()

    weak var delegate: SpeechProcessorDelegate?

    // MARK: - Init

    init(sampleRate: Double = 48_000,
         channels: AVAudioChannelCount = 1,
         interleaved: Bool = true) {

        self.sampleRate = sampleRate
        self.channels = channels
        self.interleaved = interleaved

        // Load Deepgram API key from env
        guard let key = ProcessInfo.processInfo.environment["DEEPGRAM_API_KEY"] else {
            fatalError("Deepgram API Key not found.")
        }
        self.deepgramKey = key

        socket.delegate = self
        configureAudioEngine()
        socket.connect()
    }

    // MARK: - Audio engine (macOS – no AVAudioSession)

    private func configureAudioEngine() {
        let inputNode = audioEngine.inputNode
        let inputFormat = inputNode.inputFormat(forBus: 0)

        audioEngine.attach(converterNode)
        audioEngine.attach(sinkNode)

        // Tap the converter node in Int16 format so we can stream linear16
        converterNode.installTap(onBus: 0,
                                 bufferSize: 1024,
                                 format: outputFormat) { [weak self] buffer, _ in
            guard let self = self else { return }
            if let data = self.convertAudio(buffer: buffer) {
                self.socket.write(data: data)
            }
        }

        audioEngine.connect(inputNode, to: converterNode, format: inputFormat)
        audioEngine.connect(converterNode, to: sinkNode, format: outputFormat)
        audioEngine.prepare()

        do {
            try audioEngine.start()
            logger.info("Audio engine started.")
        } catch {
            logger.error("Failed to start audio engine: \(error.localizedDescription, privacy: .public)")
        }
    }

    /// Convert the tapped Int16 buffer into raw Data for Deepgram.
    private func convertAudio(buffer: AVAudioPCMBuffer) -> Data? {
        let audioBuffer = buffer.audioBufferList.pointee.mBuffers
        guard let mData = audioBuffer.mData else { return nil }
        return Data(bytes: mData, count: Int(audioBuffer.mDataByteSize))
    }

    // MARK: - WebSocket delegate

    func didReceive(event: Starscream.WebSocketEvent,
                    client: WebSocketClient) {

        switch event {
        case .connected(let headers):
            logger.info("WebSocket connected with headers: \(headers, privacy: .public)")

        case .disconnected(let reason, let code):
            logger.info("WebSocket disconnected. Reason: \(reason, privacy: .public), code: \(code)")

        case .text(let text):
            if let data = text.data(using: .utf8) {
                processJSON(data: data)
            }

        case .error(let error):
            if let error = error {
                logger.error("WebSocket error: \(error.localizedDescription, privacy: .public)")
            } else {
                logger.error("WebSocket error: unknown")
            }

        default:
            break
        }
    }

    // MARK: - Deepgram JSON → delegate chunks

    public func processJSON(data: Data) {
        do {
            let response = try JSONDecoder().decode(DeepgramResponse.self, from: data)
            guard let alternatives = response.channel?.alternatives else { return }

            for alt in alternatives {
                if let words = alt.words, !words.isEmpty {
                    var speakerSentences: [String: (text: String, start: Double?, end: Double?)] = [:]

                    for wordInfo in words {
                        let speakerID = wordInfo.speaker.map { "spk_\($0)" } ?? "user"

                        if var entry = speakerSentences[speakerID] {
                            entry.text += wordInfo.word + " "
                            entry.end = wordInfo.end
                            speakerSentences[speakerID] = entry
                        } else {
                            speakerSentences[speakerID] = (
                                text: wordInfo.word + " ",
                                start: wordInfo.start,
                                end: wordInfo.end
                            )
                        }
                    }

                    for (speakerID, entry) in speakerSentences {
                        let trimmed = entry.text.trimmingCharacters(in: .whitespaces)
                        guard !trimmed.isEmpty else { continue }

                        conversation[speakerID, default: []].append(trimmed)

                        let chunk = DeepgramTranscriptChunk(
                            speakerID: speakerID,
                            start_time: entry.start,
                            end_time: entry.end,
                            text: trimmed,
                            isFinal: true          // we treat each sentence as final
                        )

                        delegate?.speechProcessor(self, didReceiveChunk: chunk)
                        logger.info("Speaker: \(speakerID, privacy: .public), Sentence: \(trimmed, privacy: .public)")
                    }

                } else if let transcript = alt.transcript?.trimmingCharacters(in: .whitespaces),
                          !transcript.isEmpty {

                    let speakerID = "user"
                    conversation[speakerID, default: []].append(transcript)

                    let chunk = DeepgramTranscriptChunk(
                        speakerID: speakerID,
                        start_time: nil,
                        end_time: nil,
                        text: transcript,
                        isFinal: true
                    )

                    delegate?.speechProcessor(self, didReceiveChunk: chunk)
                    logger.info("Speaker: \(speakerID, privacy: .public), Sentence: \(transcript, privacy: .public)")
                }
            }
        } catch {
            logger.error("Failed to decode Deepgram JSON: \(error.localizedDescription, privacy: .public)")
        }
    }

    // MARK: - Teardown

    public func deconfigureAudioEngine() {
        conversation.removeAll()
        audioEngine.reset()
        audioEngine.stop()
        converterNode.removeTap(onBus: 0)
        socket.disconnect(closeCode: 1000)
        socket.delegate = nil
    }
}
